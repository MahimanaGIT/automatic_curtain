var struct_t_m_c2208__n_1_1_p_w_m___s_c_a_l_e__t =
[
    [ "pwm_scale_auto", "struct_t_m_c2208__n_1_1_p_w_m___s_c_a_l_e__t.html#a08ef94aee7c3e8aed9c7a67cb80fcfb5", null ],
    [ "pwm_scale_sum", "struct_t_m_c2208__n_1_1_p_w_m___s_c_a_l_e__t.html#a437bade63cf85eb483657750aaeffd48", null ],
    [ "sr", "struct_t_m_c2208__n_1_1_p_w_m___s_c_a_l_e__t.html#a80519708e8b01bd6071f1f3c814f32b5", null ]
];