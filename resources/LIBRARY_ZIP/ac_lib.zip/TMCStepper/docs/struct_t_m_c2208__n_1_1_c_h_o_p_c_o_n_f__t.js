var struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t =
[
    [ "__pad0__", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#ad85d97d404700d8740fe7d518688e7f5", null ],
    [ "dedge", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#afe34fa5bead0fce3a95d8f27f81ceb90", null ],
    [ "diss2g", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#ad898d7610b1b98cbe974934743518616", null ],
    [ "diss2vs", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#a43c9ceb625c08d146d72413e12a77d31", null ],
    [ "hend", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#af140a1483776ad8fbf0d7f8eac7ad578", null ],
    [ "hstrt", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#a1500c76361a85e5184770d57462b2417", null ],
    [ "intpol", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#aecc82281a22683ec3ed474d26b5aec08", null ],
    [ "mres", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#a26a374e4b478e8dd4b3e283be4a25421", null ],
    [ "sr", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#a6188a535b85b0606fd7df72c8e61bcfc", null ],
    [ "tbl", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#a8e2c701d20efabf12c18cc63411038c3", null ],
    [ "toff", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#a509ce5f544d9536d8375e57dad67b0ef", null ],
    [ "vsense", "struct_t_m_c2208__n_1_1_c_h_o_p_c_o_n_f__t.html#a57d303150e8abdd83715c9c5c3236c8e", null ]
];