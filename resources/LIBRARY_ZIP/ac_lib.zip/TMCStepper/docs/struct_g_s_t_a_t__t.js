var struct_g_s_t_a_t__t =
[
    [ "drv_err", "struct_g_s_t_a_t__t.html#a1238dcdc1cd37262314295a597423bf0", null ],
    [ "reset", "struct_g_s_t_a_t__t.html#a3a5e2d2e296f693f4770d102731f07de", null ],
    [ "sr", "struct_g_s_t_a_t__t.html#ae5aaab7ffd317def5532fae52dc1f602", null ],
    [ "uv_cp", "struct_g_s_t_a_t__t.html#afefa7f9e8e56da42ee90f9abe754ba71", null ]
];