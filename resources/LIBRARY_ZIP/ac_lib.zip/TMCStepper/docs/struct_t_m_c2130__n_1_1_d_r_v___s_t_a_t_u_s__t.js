var struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t =
[
    [ "__pad0__", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a8153e82c1df8c1d18d49b8299a76cb1d", null ],
    [ "cs_actual", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#adbd64041904b2d46e1a2e1190c17ea6c", null ],
    [ "fsactive", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#af421412f249f2cc609cc62979d3eaeff", null ],
    [ "ola", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a3782ea00dbbeefa22649d96e451952dd", null ],
    [ "olb", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#aa78f9bf3389e80c9c07e23503ac31bf4", null ],
    [ "ot", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a1d98e81d1a81c7431f5728c37f81cb01", null ],
    [ "otpw", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#aeecd8bab49e428b4b615ece7da94a7af", null ],
    [ "s2ga", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a7e7330da64aa49ae4aa9d67ac60c7437", null ],
    [ "s2gb", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a5a9f010f7ca1bd4c909419c6c5abe1f1", null ],
    [ "sg_result", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#ad8b9edad686910edf09f48a5fb5e8fa4", null ],
    [ "sr", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a53ddff983723d81251a23d5ca86e0119", null ],
    [ "stallGuard", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a57dc552d5a026e08340115fb919fedeb", null ],
    [ "stst", "struct_t_m_c2130__n_1_1_d_r_v___s_t_a_t_u_s__t.html#a64316987a9d321f4eafe8de0a04a920d", null ]
];