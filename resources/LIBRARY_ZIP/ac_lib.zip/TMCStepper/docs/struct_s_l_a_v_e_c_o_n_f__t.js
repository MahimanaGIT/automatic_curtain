var struct_s_l_a_v_e_c_o_n_f__t =
[
    [ "senddelay", "struct_s_l_a_v_e_c_o_n_f__t.html#a4045a252fb7007d02e77c8191b0b21f2", null ],
    [ "slaveaddr", "struct_s_l_a_v_e_c_o_n_f__t.html#a9ff0a3b598f9a0e5d859e9b5fe500fd5", null ],
    [ "sr", "struct_s_l_a_v_e_c_o_n_f__t.html#a00b0f005125a6c917baa5caa7c5129c3", null ]
];