var struct_t_m_c2208__n_1_1_g_c_o_n_f__t =
[
    [ "en_spreadcycle", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#a6cc0edb46fbd61e3de1bbc15f2006a09", null ],
    [ "i_scale_analog", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#affdd8ea131db887ff9c3c78c67c4e9ca", null ],
    [ "index_otpw", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#aa9cec746caf08b6e1b10cb4ac466d6a1", null ],
    [ "index_step", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#a2bf96887a6bd9976a9bb467b09a2dce9", null ],
    [ "internal_rsense", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#afd632dd101410ed8bf5f9a5948cd67cd", null ],
    [ "mstep_reg_select", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#ac89481977b125957017bdb2e63c6562a", null ],
    [ "multistep_filt", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#a2ae8d605d065831424dbece9d13e1a33", null ],
    [ "pdn_disable", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#a53bb186ba8d4e9e09aac3ec5a3b64b35", null ],
    [ "shaft", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#a5b412e84c9f15c435133bddd823b91d0", null ],
    [ "sr", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#a0aeadefe2f6d9bfbdf5c93504b1e2632", null ],
    [ "test_mode", "struct_t_m_c2208__n_1_1_g_c_o_n_f__t.html#afbac5a47790784597902bb4e21dcbc4d", null ]
];