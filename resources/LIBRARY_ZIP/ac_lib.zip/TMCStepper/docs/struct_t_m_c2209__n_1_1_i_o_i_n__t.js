var struct_t_m_c2209__n_1_1_i_o_i_n__t =
[
    [ "__pad0__", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#aaa6848ee35c573e77cf6a47458a349ef", null ],
    [ "diag", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#ac012d830e1242fa24663514d8e239de2", null ],
    [ "dir", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#a7b4cd929748814c5718060e259b58f48", null ],
    [ "enn", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#aa10b92caaf903d8b34b7d7c59f95840e", null ],
    [ "ms1", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#ad93a5b4b7b84274463292004f61c6f71", null ],
    [ "ms2", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#a57cb72cf9286b554d96122acbfb0e667", null ],
    [ "pdn_uart", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#a16fb30de9ef358a953f2c63788204e5f", null ],
    [ "spread_en", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#a74a20454237a49cf47390453aae24e95", null ],
    [ "sr", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#abd05aa90c034cb8ae6936c6073834d26", null ],
    [ "step", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#a290c9bf797bdd50777d1587d288211a7", null ],
    [ "version", "struct_t_m_c2209__n_1_1_i_o_i_n__t.html#a956d983d5fbaf059de20e58b771a42da", null ]
];