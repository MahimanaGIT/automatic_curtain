var struct_t_m_c2160__n_1_1_i_o_i_n__t =
[
    [ "dco_cfg6", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#abe1026fae9e5017dfa5f55fa76ebf723", null ],
    [ "drv_enn", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#aa469d71d41e2854bc4d3b4ece6f01706", null ],
    [ "enca_dcin_cfg5", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#a7a109bb83e2ecfd0e461a262ac582c0a", null ],
    [ "encb_dcen_cfg4", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#add7215643a2915e818319b0e3d727bb0", null ],
    [ "refl_step", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#ac23c064e247687ff20186e7a05fe1809", null ],
    [ "refr_dir", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#af1b7bac6b83e44136955b857524cc2ab", null ],
    [ "sr", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#af87984452b2d1ea969153f7321355202", null ],
    [ "uint16_t", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#ada73ad3f4af4e50c5b07ccfefce28a0a", null ],
    [ "version", "struct_t_m_c2160__n_1_1_i_o_i_n__t.html#a78f7605346edf7ba943b961fe0a3366e", null ]
];