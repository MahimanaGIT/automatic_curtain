var _t_m_c__platforms_8h =
[
    [ "readMISO", "_t_m_c__platforms_8h.html#a1b0729059441b53f83a633fbf0ab315f", null ],
    [ "writeMOSI_H", "_t_m_c__platforms_8h.html#aae28defc4c391982df05cb414663956e", null ],
    [ "writeMOSI_L", "_t_m_c__platforms_8h.html#a00ddb733cb8aae0fc31326e4163cc638", null ],
    [ "writeSCK_H", "_t_m_c__platforms_8h.html#a889f92ec583d898b35cf083e12ef371a", null ],
    [ "writeSCK_L", "_t_m_c__platforms_8h.html#a595d617b4d8e35526e7c38367baf637c", null ]
];