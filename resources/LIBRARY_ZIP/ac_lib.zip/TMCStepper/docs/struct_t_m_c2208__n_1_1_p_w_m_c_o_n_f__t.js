var struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t =
[
    [ "freewheel", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a646a0bd2d0f5fb14b9e90e7cf492774e", null ],
    [ "pwm_autograd", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a646e6dae2d6f9a2924e625582c961365", null ],
    [ "pwm_autoscale", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a8effce2a0972653bdc3610b05286d0ee", null ],
    [ "pwm_freq", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a9eb47e27b4381a8b0bcd1e11ba69f474", null ],
    [ "pwm_grad", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a610e6c2239fcb8f191d5edbe73e7ca3f", null ],
    [ "pwm_lim", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a2b6dff95880880def3ff913142577af3", null ],
    [ "pwm_ofs", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a1dd3668c38be09cf4d2f548257c9e5f0", null ],
    [ "pwm_reg", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a1cbb5af5e3a40b3cd287f218f9306558", null ],
    [ "sr", "struct_t_m_c2208__n_1_1_p_w_m_c_o_n_f__t.html#a1bda8826bf8dd8e18242ddc40ada8900", null ]
];