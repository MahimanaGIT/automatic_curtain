var struct_t_m_c2224__n_1_1_i_o_i_n__t =
[
    [ "__pad0__", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#aa12600f994ab9da7659b2d79289df4ba", null ],
    [ "__pad1__", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#afd7a845c94c42a6d41ba2991689f8d29", null ],
    [ "dir", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#acc8127e6cdbb24c362046e66506b9e73", null ],
    [ "enn", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#a4d8cf9f6754dadf4b02e9a45383b8964", null ],
    [ "ms1", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#a0acd7b3eb2ad18e8c2c6a589346102d1", null ],
    [ "ms2", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#aee58dc5bdb6c0d36b3be0a92bc223435", null ],
    [ "pdn_uart", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#ae7e831d97c5282584722298788fb1db6", null ],
    [ "sel_a", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#ae0f6f56029839e5d46552cf8189d903f", null ],
    [ "spread", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#a6c290114fe8c5dc3b85a8b466a686a0b", null ],
    [ "sr", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#a593ce7848831a10bb9e7d69040f770d0", null ],
    [ "step", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#a04b1f7f08afde02632b319565a01d39d", null ],
    [ "version", "struct_t_m_c2224__n_1_1_i_o_i_n__t.html#a84946ee08cf92db1c6527b819ceb146c", null ]
];