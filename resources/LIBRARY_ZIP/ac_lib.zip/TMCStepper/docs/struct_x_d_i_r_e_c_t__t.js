var struct_x_d_i_r_e_c_t__t =
[
    [ "__pad0__", "struct_x_d_i_r_e_c_t__t.html#ae7b2f87b68ac7cb569aa2dedfacea909", null ],
    [ "coil_A", "struct_x_d_i_r_e_c_t__t.html#a63362b0f5a7951e4b72dad4d3c34dd85", null ],
    [ "coil_B", "struct_x_d_i_r_e_c_t__t.html#a185e2d0eb0b951ee8c46311744880d9d", null ],
    [ "sr", "struct_x_d_i_r_e_c_t__t.html#a587afc7ed2594677b6933e82e15f2a9f", null ]
];