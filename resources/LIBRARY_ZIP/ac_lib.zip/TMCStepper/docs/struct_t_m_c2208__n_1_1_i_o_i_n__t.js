var struct_t_m_c2208__n_1_1_i_o_i_n__t =
[
    [ "__pad0__", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#add8ffd5f86ea97e4152abcb6a10fa1b0", null ],
    [ "diag", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#a774528453c7104bcc541776c81e6d457", null ],
    [ "dir", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#a94df0eb8a2d2ec176a64b5924c6abdbe", null ],
    [ "enn", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#ad8825053bd1986513e6f974e8398b192", null ],
    [ "ms1", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#af9f0825fdf4a267e6adaac598aa0d70a", null ],
    [ "ms2", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#a2e868c8c64a461316286d1d9e300458a", null ],
    [ "pdn_uart", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#a0997a1077f09b5ca69d1a7fe29c1305d", null ],
    [ "sel_a", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#a1461f9f475e11f3be21b03ff4abcd290", null ],
    [ "sr", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#a1d538558c5041d9633c0e4cc60c81356", null ],
    [ "step", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#a3afd216dd0da0d3fbf8abb21e080c40e", null ],
    [ "version", "struct_t_m_c2208__n_1_1_i_o_i_n__t.html#ab9bcfd865d236fe039405b530944054b", null ]
];