var struct_t_z_e_r_o_w_a_i_t__t =
[
    [ "sr", "struct_t_z_e_r_o_w_a_i_t__t.html#a79568aa31b9b53fe88bb78964616234c", null ]
];